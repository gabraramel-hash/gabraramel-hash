package com.hotshare.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * HotShare — تبادل ملفات بين هاتفين على نفس الهوتسبوت.
 * المستقبل: يفتح TCP 8988 ويبث "أنا هون" على UDP 8989 كل ثانية.
 * المرسل: يسمع على UDP 8989، يعبّي العنوان لحالو، ويبعت الملفات.
 */
public class MainActivity extends Activity {

    static final int TCP_PORT = 8988;
    static final int UDP_PORT = 8989;
    static final String MAGIC = "HOTSHARE1";
    static final String BEACON = "HOTSHARE|";
    static final String FOLDER = "HotShare";
    static final int REQ_PICK = 11;
    static final int BUF = 1 << 16;

    static final int C_BG = 0xFF0F172A, C_CARD = 0xFF1E293B, C_GREEN = 0xFF22C55E,
            C_BLUE = 0xFF3B82F6, C_RED = 0xFFEF4444, C_TXT = 0xFFF1F5F9, C_SUB = 0xFF94A3B8;

    final Handler ui = new Handler(Looper.getMainLooper());

    LinearLayout panelReceive, panelSend;
    Button tabReceive, tabSend;

    // ---- استقبال
    TextView rxIps, rxStatus, rxLog;
    ProgressBar rxBar;
    Button rxToggle;
    volatile boolean receiving = false;
    ServerSocket server;

    // ---- إرسال
    EditText txIp;
    TextView txFound, txFiles, txStatus;
    ProgressBar txBar;
    Button txPick, txGo;
    final ArrayList<Uri> picked = new ArrayList<>();
    volatile boolean listening = false;
    volatile boolean sending = false;
    DatagramSocket udp;
    WifiManager.MulticastLock mlock;
    String lastAutoIp = "";

    // =====================================================================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 5);
        }
        if (!handleShareIntent(getIntent())) showReceive();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleShareIntent(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshIps();
    }

    @Override
    protected void onDestroy() {
        stopReceive();
        stopDiscovery();
        super.onDestroy();
    }

    boolean handleShareIntent(Intent i) {
        if (i == null) return false;
        String a = i.getAction();
        ArrayList<Uri> list = new ArrayList<>();
        if (Intent.ACTION_SEND.equals(a)) {
            Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) list.add(u);
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(a)) {
            ArrayList<Uri> us = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (us != null) list.addAll(us);
        } else {
            return false;
        }
        if (list.isEmpty()) return false;
        picked.clear();
        picked.addAll(list);
        updatePicked();
        showSend();
        return true;
    }

    // =====================================================================
    // واجهة
    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    Button button(String s, int color) {
        Button bt = new Button(this);
        bt.setText(s);
        bt.setTextColor(Color.WHITE);
        bt.setTextSize(17);
        bt.setAllCaps(false);
        bt.setBackground(round(color, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        bt.setLayoutParams(lp);
        return bt;
    }

    ProgressBar bar() {
        ProgressBar p = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        p.setMax(1000);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(14));
        lp.topMargin = dp(12);
        p.setLayoutParams(lp);
        return p;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(C_CARD, 18));
        l.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        l.setLayoutParams(lp);
        return l;
    }

    void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(24));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.addView(root);

        TextView title = text("HotShare  •  تبادل الملفات", 24, C_TXT, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView sub = text("شغّل الهوتسبوت على هاتف، وصّل التاني عليه، وبعدين ابعت.", 14, C_SUB, false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        // تبويبات
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
        tl.topMargin = dp(14);
        tabs.setLayoutParams(tl);
        tabReceive = button("📥  استقبال", C_CARD);
        tabSend = button("📤  إرسال", C_CARD);
        LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, dp(54), 1f);
        a1.setMargins(dp(4), 0, dp(4), 0);
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, dp(54), 1f);
        a2.setMargins(dp(4), 0, dp(4), 0);
        tabReceive.setLayoutParams(a1);
        tabSend.setLayoutParams(a2);
        tabs.addView(tabReceive);
        tabs.addView(tabSend);
        root.addView(tabs);
        tabReceive.setOnClickListener(v -> showReceive());
        tabSend.setOnClickListener(v -> showSend());

        // ---------- لوحة الاستقبال
        panelReceive = new LinearLayout(this);
        panelReceive.setOrientation(LinearLayout.VERTICAL);
        LinearLayout c1 = card();
        c1.addView(text("عنوان هالجهاز", 14, C_SUB, false));
        rxIps = text("…", 20, C_TXT, true);
        rxIps.setTextDirection(View.TEXT_DIRECTION_LTR);
        c1.addView(rxIps);
        rxToggle = button("ابدأ الاستقبال", C_GREEN);
        rxToggle.setOnClickListener(v -> { if (receiving) stopReceive(); else startReceive(); });
        c1.addView(rxToggle);
        rxStatus = text("متوقف", 15, C_SUB, false);
        c1.addView(rxStatus);
        rxBar = bar();
        c1.addView(rxBar);
        panelReceive.addView(c1);
        LinearLayout c2 = card();
        c2.addView(text("الملفات المستلمة  ←  Download/HotShare", 14, C_SUB, false));
        rxLog = text("—", 14, C_TXT, false);
        c2.addView(rxLog);
        panelReceive.addView(c2);
        root.addView(panelReceive);

        // ---------- لوحة الإرسال
        panelSend = new LinearLayout(this);
        panelSend.setOrientation(LinearLayout.VERTICAL);
        LinearLayout s1 = card();
        s1.addView(text("عنوان الجهاز المستقبل", 14, C_SUB, false));
        txIp = new EditText(this);
        txIp.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        txIp.setHint("192.168.x.x");
        txIp.setTextColor(C_TXT);
        txIp.setHintTextColor(C_SUB);
        txIp.setTextSize(20);
        txIp.setTextDirection(View.TEXT_DIRECTION_LTR);
        txIp.setGravity(Gravity.CENTER);
        txIp.setBackground(round(C_BG, 12));
        txIp.setPadding(dp(12), dp(10), dp(12), dp(10));
        s1.addView(txIp);
        txFound = text("🔎 عم دوّر على جهاز مستقبل…", 14, C_SUB, false);
        s1.addView(txFound);
        panelSend.addView(s1);

        LinearLayout s2 = card();
        txPick = button("اختار ملفات", C_BLUE);
        txPick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, REQ_PICK);
        });
        s2.addView(txPick);
        txFiles = text("ما في ملفات مختارة", 14, C_SUB, false);
        s2.addView(txFiles);
        txGo = button("إرسال", C_GREEN);
        txGo.setOnClickListener(v -> startSend());
        s2.addView(txGo);
        txStatus = text("", 15, C_SUB, false);
        s2.addView(txStatus);
        txBar = bar();
        s2.addView(txBar);
        panelSend.addView(s2);
        root.addView(panelSend);

        setContentView(sv);
    }

    void showReceive() {
        panelReceive.setVisibility(View.VISIBLE);
        panelSend.setVisibility(View.GONE);
        tabReceive.setBackground(round(C_GREEN, 14));
        tabSend.setBackground(round(C_CARD, 14));
        stopDiscovery();
        refreshIps();
    }

    void showSend() {
        panelSend.setVisibility(View.VISIBLE);
        panelReceive.setVisibility(View.GONE);
        tabSend.setBackground(round(C_BLUE, 14));
        tabReceive.setBackground(round(C_CARD, 14));
        if (txIp.getText().length() == 0) {
            String g = gateway();
            if (g != null) { txIp.setText(g); lastAutoIp = g; }
        }
        startDiscovery();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void refreshIps() {
        new Thread(() -> {
            String t = ipsText();
            ui.post(() -> { if (rxIps != null) rxIps.setText(t); });
        }).start();
    }

    // =====================================================================
    // شبكة — أدوات
    static boolean skipIface(NetworkInterface ni) throws Exception {
        if (!ni.isUp() || ni.isLoopback()) return true;
        String n = ni.getName();
        return n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("dummy")
                || n.startsWith("tun") || n.startsWith("ims") || n.startsWith("p2p");
    }

    static List<String> localIps() {
        ArrayList<String> r = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (skipIface(ni)) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (a instanceof Inet4Address) r.add(a.getHostAddress());
            }
        } catch (Exception ignored) { }
        return r;
    }

    static List<InetAddress> broadcasts() {
        ArrayList<InetAddress> r = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (skipIface(ni)) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses())
                    if (ia.getBroadcast() != null) r.add(ia.getBroadcast());
            }
            r.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) { }
        return r;
    }

    static String ipsText() {
        List<String> ips = localIps();
        if (ips.isEmpty()) return "ما في شبكة — شغّل الهوتسبوت أو اتصل بواحد";
        StringBuilder sb = new StringBuilder();
        for (String s : ips) { if (sb.length() > 0) sb.append('\n'); sb.append(s); }
        return sb.toString();
    }

    String gateway() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            int g = wm.getDhcpInfo().gateway;
            if (g == 0) return null;
            return (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >>> 24) & 0xff);
        } catch (Exception e) {
            return null;
        }
    }

    static String human(long b) {
        if (b < 1024) return b + " B";
        double k = b / 1024.0;
        if (k < 1024) return String.format(Locale.US, "%.0f KB", k);
        double m = k / 1024.0;
        if (m < 1024) return String.format(Locale.US, "%.1f MB", m);
        return String.format(Locale.US, "%.2f GB", m / 1024.0);
    }

    static String msg(Exception e) {
        return e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
    }

    static String clean(String n) {
        String s = n.replaceAll("[\\\\/:*?\"<>|\\x00-\\x1F]", "_").trim();
        if (s.isEmpty() || s.equals(".") || s.equals("..")) s = "file_" + System.currentTimeMillis();
        return s;
    }

    static String mime(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0) {
            String t = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(Locale.US));
            if (t != null) return t;
        }
        return "application/octet-stream";
    }

    void progress(final boolean rx, final String label, long done, long total, long t0) {
        long ms = Math.max(1, System.currentTimeMillis() - t0);
        final int p = total > 0 ? (int) (done * 1000 / total) : 0;
        final String line = label + "\n" + human(done) + " / " + human(total)
                + "   •   " + human(done * 1000 / ms) + "/s";
        ui.post(() -> {
            if (rx) { rxStatus.setText(line); rxBar.setProgress(p); }
            else { txStatus.setText(line); txBar.setProgress(p); }
        });
    }

    // =====================================================================
    // استقبال
    void startReceive() {
        if (receiving) return;
        receiving = true;
        rxToggle.setText("إيقاف الاستقبال");
        rxToggle.setBackground(round(C_RED, 14));
        rxStatus.setText("✅ جاهز… ناطر ملفات");
        rxBar.setProgress(0);
        refreshIps();

        new Thread(() -> {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(TCP_PORT));
                server = ss;
                while (receiving) {
                    Socket s = ss.accept();
                    try {
                        receiveFrom(s);
                    } catch (Exception e) {
                        final String m = msg(e);
                        ui.post(() -> rxStatus.setText("❌ انقطع الاستلام: " + m + "\nجاهز لمحاولة جديدة"));
                    } finally {
                        try { s.close(); } catch (Exception ignored) { }
                    }
                }
            } catch (Exception e) {
                if (receiving) {
                    final String m = msg(e);
                    ui.post(() -> { stopReceive(); rxStatus.setText("❌ ما قدرت افتح المنفذ: " + m); });
                }
            }
        }).start();

        new Thread(this::beaconLoop).start();
    }

    void stopReceive() {
        receiving = false;
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        server = null;
        if (rxToggle != null) {
            rxToggle.setText("ابدأ الاستقبال");
            rxToggle.setBackground(round(C_GREEN, 14));
            rxStatus.setText("متوقف");
        }
    }

    void beaconLoop() {
        DatagramSocket ds = null;
        try {
            ds = new DatagramSocket();
            ds.setBroadcast(true);
            byte[] p = (BEACON + Build.MANUFACTURER + " " + Build.MODEL).getBytes("UTF-8");
            while (receiving) {
                for (InetAddress b : broadcasts()) {
                    try { ds.send(new DatagramPacket(p, p.length, b, UDP_PORT)); } catch (Exception ignored) { }
                }
                final String t = ipsText();
                ui.post(() -> rxIps.setText(t));
                Thread.sleep(1000);
            }
        } catch (Exception ignored) {
        } finally {
            if (ds != null) ds.close();
        }
    }

    void appendLog(String line) {
        String cur = rxLog.getText().toString();
        rxLog.setText(cur.equals("—") ? line : line + "\n" + cur);
    }

    void receiveFrom(Socket s) throws IOException {
        s.setSoTimeout(30000);
        DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), BUF));
        DataOutputStream out = new DataOutputStream(s.getOutputStream());
        if (!MAGIC.equals(in.readUTF())) return;
        final int count = in.readInt();
        final long total = in.readLong();
        final String from = s.getInetAddress().getHostAddress();

        byte[] buf = new byte[BUF];
        long done = 0, t0 = System.currentTimeMillis(), lastUi = 0;
        for (int i = 0; i < count; i++) {
            final String name = clean(in.readUTF());
            long size = in.readLong();
            Sink sink = openSink(name);
            boolean ok = false;
            try {
                long rem = size;
                while (rem > 0) {
                    int n = in.read(buf, 0, (int) Math.min(buf.length, rem));
                    if (n < 0) throw new EOFException("الاتصال انقطع");
                    sink.os.write(buf, 0, n);
                    rem -= n;
                    done += n;
                    long now = System.currentTimeMillis();
                    if (now - lastUi > 200) {
                        lastUi = now;
                        progress(true, "⬇️ (" + (i + 1) + "/" + count + ")  " + name, done, total, t0);
                    }
                }
                sink.os.flush();
                ok = true;
            } finally {
                sink.close(ok);
            }
            ui.post(() -> appendLog("✅ " + name));
        }
        out.writeUTF("OK");
        out.flush();
        ui.post(() -> {
            rxStatus.setText("✅ وصل " + count + " ملف (" + human(total) + ") من " + from + "\nجاهز لاستلام غيرن");
            rxBar.setProgress(1000);
        });
    }

    class Sink {
        OutputStream os;
        Uri uri;
        File file;

        void close(boolean ok) {
            try { os.close(); } catch (Exception ignored) { }
            if (uri != null) {
                if (ok) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(uri, v, null, null);
                } else {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                }
            } else if (file != null) {
                if (!ok) file.delete();
                else MediaScannerConnection.scanFile(MainActivity.this, new String[]{file.getAbsolutePath()}, null, null);
            }
        }
    }

    Sink openSink(String name) throws IOException {
        Sink k = new Sink();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime(name));
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new IOException("ما قدرت انشئ الملف " + name);
            k.uri = u;
            OutputStream o = getContentResolver().openOutputStream(u);
            if (o == null) throw new IOException("ما قدرت اكتب الملف " + name);
            k.os = o;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER);
            dir.mkdirs();
            String base = name, ext = "";
            int dot = name.lastIndexOf('.');
            if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
            File f = new File(dir, name);
            int n = 1;
            while (f.exists()) f = new File(dir, base + " (" + (n++) + ")" + ext);
            k.file = f;
            k.os = new FileOutputStream(f);
        }
        k.os = new BufferedOutputStream(k.os, BUF);
        return k;
    }

    // =====================================================================
    // إرسال
    static class Item {
        Uri uri;
        String name;
        long size = -1;
        File temp;
    }

    Item meta(Uri u) {
        Item it = new Item();
        it.uri = u;
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0) it.name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) it.size = c.getLong(si);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        if (it.name == null || it.name.isEmpty()) {
            String p = u.getLastPathSegment();
            it.name = p != null ? p.substring(p.lastIndexOf('/') + 1) : "file_" + System.currentTimeMillis();
        }
        return it;
    }

    /** إذا الحجم مش معروف، منسخ الملف مؤقتاً لنعرف حجمه. */
    Item describe(Uri u) throws IOException {
        Item it = meta(u);
        if (it.size < 0) {
            File t = File.createTempFile("hs", ".tmp", getCacheDir());
            InputStream is = getContentResolver().openInputStream(u);
            if (is == null) throw new IOException("ما قدرت افتح " + it.name);
            OutputStream os = new FileOutputStream(t);
            try {
                byte[] b = new byte[BUF];
                int n;
                while ((n = is.read(b)) > 0) os.write(b, 0, n);
            } finally {
                is.close();
                os.close();
            }
            it.temp = t;
            it.size = t.length();
        }
        return it;
    }

    @Override
    protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq != REQ_PICK || rc != RESULT_OK || d == null) return;
        picked.clear();
        ClipData cd = d.getClipData();
        if (cd != null) {
            for (int k = 0; k < cd.getItemCount(); k++) picked.add(cd.getItemAt(k).getUri());
        } else if (d.getData() != null) {
            picked.add(d.getData());
        }
        updatePicked();
    }

    void updatePicked() {
        if (picked.isEmpty()) { txFiles.setText("ما في ملفات مختارة"); return; }
        long total = 0;
        StringBuilder names = new StringBuilder();
        int shown = 0;
        for (Uri u : picked) {
            Item it = meta(u);
            if (it.size > 0) total += it.size;
            if (shown < 6) { names.append("\n• ").append(it.name); shown++; }
        }
        if (picked.size() > 6) names.append("\n… و ").append(picked.size() - 6).append(" غيرن");
        txFiles.setText("📄 " + picked.size() + " ملف  •  " + human(total) + names);
        txFiles.setTextColor(C_TXT);
    }

    void startSend() {
        if (sending) return;
        final String ip = txIp.getText().toString().trim();
        if (ip.isEmpty()) { toast("اكتب عنوان المستقبل"); return; }
        if (picked.isEmpty()) { toast("اختار ملفات أوّل"); return; }
        sending = true;
        txGo.setEnabled(false);
        txPick.setEnabled(false);
        txStatus.setText("⏳ عم اتصل بـ " + ip + " …");
        txBar.setProgress(0);
        final ArrayList<Uri> uris = new ArrayList<>(picked);

        new Thread(() -> {
            ArrayList<Item> items = new ArrayList<>();
            Socket s = new Socket();
            try {
                long total = 0;
                for (Uri u : uris) { Item it = describe(u); items.add(it); total += it.size; }

                s.connect(new InetSocketAddress(ip, TCP_PORT), 6000);
                s.setSoTimeout(60000);
                s.setSendBufferSize(BUF * 4);
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), BUF));
                DataInputStream in = new DataInputStream(s.getInputStream());
                out.writeUTF(MAGIC);
                out.writeInt(items.size());
                out.writeLong(total);

                byte[] buf = new byte[BUF];
                long done = 0, t0 = System.currentTimeMillis(), lastUi = 0;
                for (int i = 0; i < items.size(); i++) {
                    Item it = items.get(i);
                    out.writeUTF(it.name);
                    out.writeLong(it.size);
                    InputStream is = it.temp != null ? new FileInputStream(it.temp)
                            : getContentResolver().openInputStream(it.uri);
                    if (is == null) throw new IOException("ما قدرت افتح " + it.name);
                    try {
                        long rem = it.size;
                        while (rem > 0) {
                            int n = is.read(buf, 0, (int) Math.min(buf.length, rem));
                            if (n < 0) throw new IOException("الملف تغيّر وقت الإرسال: " + it.name);
                            out.write(buf, 0, n);
                            rem -= n;
                            done += n;
                            long now = System.currentTimeMillis();
                            if (now - lastUi > 200) {
                                lastUi = now;
                                progress(false, "⬆️ (" + (i + 1) + "/" + items.size() + ")  " + it.name, done, total, t0);
                            }
                        }
                    } finally {
                        is.close();
                    }
                }
                out.flush();
                String ack = in.readUTF();
                final long tot = total;
                final int cnt = items.size();
                final long secs = Math.max(1, (System.currentTimeMillis() - t0) / 1000);
                ui.post(() -> {
                    txBar.setProgress(1000);
                    txStatus.setText("OK".equals(ack)
                            ? "✅ انبعتوا " + cnt + " ملف (" + human(tot) + ") بـ " + secs + " ثانية"
                            : "⚠️ انبعتوا بس المستقبل ما أكّد");
                });
            } catch (Exception e) {
                final String m = msg(e);
                ui.post(() -> txStatus.setText("❌ فشل الإرسال: " + m
                        + "\nتأكد إنو المستقبل ضاغط «ابدأ الاستقبال» وإنكن عَ نفس الهوتسبوت."));
            } finally {
                try { s.close(); } catch (Exception ignored) { }
                for (Item it : items) if (it.temp != null) it.temp.delete();
                ui.post(() -> {
                    sending = false;
                    txGo.setEnabled(true);
                    txPick.setEnabled(true);
                });
            }
        }).start();
    }

    // ---- اكتشاف المستقبل تلقائياً
    void startDiscovery() {
        if (listening) return;
        listening = true;
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            mlock = wm.createMulticastLock("hotshare");
            mlock.setReferenceCounted(false);
            mlock.acquire();
        } catch (Exception ignored) { }

        new Thread(() -> {
            DatagramSocket ds = null;
            try {
                ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.setBroadcast(true);
                ds.bind(new InetSocketAddress(UDP_PORT));
                ds.setSoTimeout(1000);
                udp = ds;
                byte[] buf = new byte[512];
                while (listening) {
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        ds.receive(p);
                        String m = new String(p.getData(), 0, p.getLength(), "UTF-8");
                        if (!m.startsWith(BEACON)) continue;
                        final String ip = p.getAddress().getHostAddress();
                        if (localIps().contains(ip)) continue;
                        final String name = m.substring(BEACON.length());
                        ui.post(() -> onFound(ip, name));
                    } catch (SocketTimeoutException ignored) { }
                }
            } catch (Exception ignored) {
            } finally {
                if (ds != null) ds.close();
            }
        }).start();
    }

    void onFound(String ip, String name) {
        txFound.setText("✅ لقيت: " + name + "  (" + ip + ")");
        txFound.setTextColor(C_GREEN);
        String cur = txIp.getText().toString().trim();
        if (cur.isEmpty() || cur.equals(lastAutoIp)) {
            if (!cur.equals(ip)) txIp.setText(ip);
            lastAutoIp = ip;
        }
    }

    void stopDiscovery() {
        listening = false;
        try { if (udp != null) udp.close(); } catch (Exception ignored) { }
        udp = null;
        try { if (mlock != null && mlock.isHeld()) mlock.release(); } catch (Exception ignored) { }
    }
}
