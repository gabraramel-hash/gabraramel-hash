#!/usr/bin/env bash
# يبني HotShare.apk بأدوات Android SDK مباشرة (بدون Gradle)
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -d "$SDK/platforms" ] || { echo "Android SDK not found"; exit 1; }

BT="$SDK/build-tools/$(ls "$SDK/build-tools" | sort -V | tail -1)"
PLAT=$(ls "$SDK/platforms" | grep -E '^android-[0-9]+$' | sed 's/android-//' | sort -n | tail -1)
JAR="$SDK/platforms/android-$PLAT/android.jar"
echo "build-tools: $BT"
echo "platform:    android-$PLAT"

rm -rf build && mkdir -p build/classes build/dex
"$BT/aapt2" compile --dir res -o build/res.zip
"$BT/aapt2" link -o build/base.apk -I "$JAR" --manifest AndroidManifest.xml \
  --min-sdk-version 24 --target-sdk-version "$PLAT" build/res.zip
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$JAR" -nowarn \
  -d build/classes src/com/hotshare/app/MainActivity.java
(cd build/classes && jar cf ../classes.jar .)
"$BT/d8" --release --min-api 24 --lib "$JAR" --output build/dex build/classes.jar
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes.dex)
"$BT/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
[ -f hotshare.jks ] || keytool -genkeypair -keystore hotshare.jks -storepass android -keypass android \
  -alias hotshare -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=HotShare"
"$BT/apksigner" sign --ks hotshare.jks --ks-pass pass:android --key-pass pass:android \
  --out HotShare.apk build/aligned.apk
echo "✅ HotShare.apk جاهز"
